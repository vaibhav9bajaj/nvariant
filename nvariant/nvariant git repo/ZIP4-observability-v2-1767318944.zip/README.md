
Observability v2 – Feature Exhaust
Emits ML-grade features from enforcement + governance signals.
