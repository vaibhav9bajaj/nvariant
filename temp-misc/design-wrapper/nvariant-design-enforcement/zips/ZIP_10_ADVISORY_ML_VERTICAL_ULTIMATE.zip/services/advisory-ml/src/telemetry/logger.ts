
export function log(msg: string, ctx?: any) {
  console.log(msg, ctx || {})
}
