
import './safety/locks'
import { startServer } from './server'

startServer()
