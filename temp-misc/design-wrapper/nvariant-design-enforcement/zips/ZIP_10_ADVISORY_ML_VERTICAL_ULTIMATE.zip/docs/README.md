
# Advisory ML Vertical (Ultimate)

Production-grade, advisory-only ML subsystem.
- Async only
- Cannot enforce
- Cannot mutate contracts
