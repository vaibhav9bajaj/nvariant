Advisory acceptance creates human-reviewable draft patches.
