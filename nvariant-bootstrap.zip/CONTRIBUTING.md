# Contributing

- `make up` to run locally
- `make fmt` + `make lint` before PRs
