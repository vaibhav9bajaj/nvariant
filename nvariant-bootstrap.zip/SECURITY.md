# Security Policy

Report vulnerabilities privately.

- Email: security@yourcompany.example
