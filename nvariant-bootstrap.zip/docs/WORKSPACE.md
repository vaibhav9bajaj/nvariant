# Workspace (V2)

This repo is a single canonical monorepo.

- Package manager: pnpm
- Task runner: Makefile (primary), Turbo (optional)

Common commands:
- `pnpm -r build`
- `make up`
- `make verify`
