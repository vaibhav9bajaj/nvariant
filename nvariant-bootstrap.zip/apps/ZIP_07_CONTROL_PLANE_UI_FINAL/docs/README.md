
# ZIP 07 – Control Plane UI (Final)

This ZIP fully replaces the previous Control Plane UI.

Included:
- Contracts
- Enforcement
- Observability
- Advisory (NEW)

Advisory surfaces:
- Model Runs
- Recommendations
- Feedback & Metrics

Notes:
- Advisory is consultative only
- No enforcement authority
- Human approval required
