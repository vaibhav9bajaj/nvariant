
export function AdvisoryMetrics() {
  return (
    <div>
      <h2>Feedback & Metrics</h2>
      <p>Accept rate, noise metrics, and model version health.</p>
    </div>
  )
}
