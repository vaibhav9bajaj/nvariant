
export function AdvisoryRuns() {
  return (
    <div>
      <h2>Model Runs</h2>
      <p>Async advisory model executions with status and metrics.</p>
    </div>
  )
}
