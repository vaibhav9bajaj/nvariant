
export function AdvisoryRecommendations() {
  return (
    <div>
      <h2>Recommendations</h2>
      <p>Advisory-only recommendations. Accept / Reject required.</p>
    </div>
  )
}
