External Secrets Operator (optional) templates.
