# Local Quickstart

```bash
make up
```

- Explorer UI: http://localhost:3100
- Control Plane UI: http://localhost:3200
- API: http://localhost:3000
