# nvariant V2 Canonical Monorepo

Merged from 13 frozen subsystems. Meta archived under /docs.
