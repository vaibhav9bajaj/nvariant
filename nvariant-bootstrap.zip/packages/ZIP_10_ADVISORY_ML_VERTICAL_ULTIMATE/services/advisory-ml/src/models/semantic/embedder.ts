
export function detectSemanticShift(values: string[]) {
  return { shiftScore: 0.0 }
}
