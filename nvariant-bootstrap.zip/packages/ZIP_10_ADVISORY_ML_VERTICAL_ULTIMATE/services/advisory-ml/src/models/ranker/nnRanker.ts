
export function rankWithNN(recs: any[]) {
  return recs
}
