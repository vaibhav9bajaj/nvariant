
export async function saveRecommendation(rec: any) {
  // insert into advisory_recommendations
}
