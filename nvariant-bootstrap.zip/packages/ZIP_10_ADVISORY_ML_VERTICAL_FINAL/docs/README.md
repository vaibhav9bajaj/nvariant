
# ZIP 10 – Advisory ML Vertical (Final)

Production-grade advisory ML subsystem.
- Async only
- Consultative only
- No enforcement authority

Safe to run alongside ZIPs 1–9.
