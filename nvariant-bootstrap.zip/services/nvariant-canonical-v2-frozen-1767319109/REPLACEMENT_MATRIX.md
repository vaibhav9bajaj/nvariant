
## Subsystem Replacement Matrix

| Subsystem | Status |
|----------|--------|
| ZIP 4 v1 | Superseded by ZIP 4 v2 |
| ZIP 7 v1 | Superseded by ZIP 7 v2 |
| ZIP 8 v1 | Superseded by ZIP 8 v2 |
| ZIP 5 | Retained as fallback baseline |
| ZIP 1–3 | Unchanged |
