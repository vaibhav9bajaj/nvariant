Smoke test for advisory integration.
