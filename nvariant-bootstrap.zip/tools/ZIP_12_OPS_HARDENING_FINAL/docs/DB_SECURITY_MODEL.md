Advisory safety is enforced at the database layer.
