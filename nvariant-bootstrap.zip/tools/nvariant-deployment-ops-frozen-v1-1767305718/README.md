
# nvariant – Deployment & Ops (ZIP 9)

This ZIP provides a complete deployment and operations layer.

Includes:
- Dockerfiles for all services
- docker-compose stack
- Environment variable contracts
- Secrets & TLS placeholders
- Local → staging → prod guidance

Goal:
Run the full nvariant system locally in minutes.
