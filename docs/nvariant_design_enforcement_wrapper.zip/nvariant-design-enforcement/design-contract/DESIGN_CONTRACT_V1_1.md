# nvariant Design Contract v1.1 (LOCKED)

Visual styling only.

Rules:
- No gradients
- No filled primary buttons
- Tables-first
- Color is semantic
- Font: Inter

Tokens in tokens.css (authoritative).

Enforcement:
- ZIP inputs immutable
- Wrapper assembles + overlays + remediates derived output
- Scan warns by default (strict optional)
